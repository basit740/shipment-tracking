const express = require("express");
const axios = require("axios");
const fs = require("fs");
const csv = require("csv-parser");

const token =
  "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6Ii13OHUyWkY1ZDdVUWRNQkpUQlNWQyJ9.eyJpc3MiOiJodHRwczovL2hlcm1lcy1jbGllbnQtaW50ZWdyYXRpb24tcHJvZC5ldS5hdXRoMC5jb20vIiwic3ViIjoibDliOWFEa0M2anFBc3d6R25RbjNIUmVSVm5oeVVweUZAY2xpZW50cyIsImF1ZCI6ImNsaWVudC10cmFja2luZy1hcGkiLCJpYXQiOjE3MTc3NzIyNjMsImV4cCI6MTcxNzg1ODY2MywiZ3R5IjoiY2xpZW50LWNyZWRlbnRpYWxzIiwiYXpwIjoibDliOWFEa0M2anFBc3d6R25RbjNIUmVSVm5oeVVweUYifQ.CMnvgb8CXHd4y02Q6QpnSwhtYgJ_GVWbbZZRxx-zXt-nXf5idk4wJBRVRfxB3keVpklJdbX8fZyGyAP86UIM3mGc2ZLnKsqpHN88kPsmZnN-vMhltjpuwJnHaGydXh01JjDC7HM6Aze94-7raW1C4EXZ6sZJZ-5kVgqEzLblb5D014rCipjBB3P_n7_QvM2e78MwuxVT87kixSpUPANEaB8ID9XgQ9cAylseVdxlLWVOvg11J--MYRHMrKeWgBic5TnBDw5jttbpRhCpcdET9Ty_10pwnzLeQQ1R1H_6LV7RZUbtzXO3ju05Yp3GeEhTBHPN_E6cuBxZncfzYzuoow";

const app = express();
const port = 3000;

let barcodes = [];
let responses = [];

const readCSV = () => {
  return new Promise((resolve, reject) => {
    fs.createReadStream("SHP.csv")
      .pipe(csv())
      .on("data", (row) => {
        barcodes.push(row["Carrier reference number"]);
      })
      .on("end", () => {
        resolve();
      })
      .on("error", reject);
  });
};

const fetchBarcodeData = async (barcode) => {
  try {
    const response = await axios.get(
      `https://api.hermesworld.co.uk/client-tracking-api/v1/etas?barcode=${barcode}`,
      {
        headers: {
          Authorization: "Bearer " + token, // Replace with your header name and value
          apikey: "wf2pX1fGGqPoGvzmqtLqrVnXApsDOARH", // Replace with your header name and value
        },
      }
    );
    return response.data;
  } catch (error) {
    console.error(`Error fetching data for barcode ${barcode}:`, error.message);
    return null;
  }
};

const processBarcodes = async () => {
  for (let i = 0; i < barcodes.length; i++) {
    if (i % 720 === 0 && i !== 0) {
      console.log("Pausing for rate limit...");
      await new Promise((resolve) => setTimeout(resolve, 60000)); // Wait for 1 minute
    }
    const barcode = barcodes[i];
    const data = await fetchBarcodeData(barcode);
    responses.push(data);
  }
};

app.get("/track-barcodes", async (req, res) => {
  await readCSV();
  await processBarcodes();
  res.send(responses);
});

app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});
